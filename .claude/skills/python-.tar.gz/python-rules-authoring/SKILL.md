---
name: python-rules-authoring
description: >-
  Conventions for writing and auditing the Python coding rules in .claude/rules/python/*.md and
  the python-* skills: stating a rule over its widest category, carve-outs beside prohibitions,
  WRONG/CORRECT pairs that differ in one dimension and obey every other rule, examples that name no
  project, one home per rule, rationed emphasis, skill descriptions as triggers, what loads when,
  the line budget for the always-loaded rules, and testing that a rule changes behaviour.
  Use when editing, adding to, splitting, auditing or evaluating these rule files and skills.
---

# Writing These Rules

## How a Rule Is Written

These files are read while writing code, under time pressure, by someone already holding a
different problem in their head. A rule that is technically correct and easy to misread will be
misread. Four conventions prevent that; a rule breaking one of them is a defect **in this
document**, fixed here rather than worked around in code.

**Stated over the widest category it is true for.** A rule written about a class gets applied to
classes and to nothing else — the reader cannot tell whether the other kinds were excluded
deliberately or never considered. Name every kind the rule covers — class, function, constant, type
alias, parameter, module — and let the examples illustrate, never define. The encapsulation rule
said "class" for months, and the cost was twenty-eight public names nobody imports.

**Every prohibition carries its carve-out in the same place.** "Never name a vendor" and
"implementations are named for what makes them concrete" are both true, and a reader who meets the
first without the second renames `SlackNotifier`. An exception three sections away does not exist.

**Every non-obvious rule says what breaks, and when.** "Names are local" is an opinion; "the model
was replaced twice and the name outlived both" is a cost with a date on it. The failure mode is
what lets a reader settle an edge case alone, and what makes the rule survive an argument with
someone in a hurry.

**Examples come in pairs: one invented, one real.** The invented pair — `# WRONG` next to
`# CORRECT` — shows the shape. The real one shows the price, which no invented example can: an
incident that actually happened, concrete enough that the failure can be pictured, told in one
sentence beside the pair. Keep both where a real incident exists; never invent one to fill the
slot — an invented incident teaches a failure nobody has seen.

**The model copies the example, not the prose.** Three consequences, each found in these files by
an audit that turned up a dozen examples teaching the opposite of the rule above them:

- **The pair differs in exactly the dimension the rule is about.** Same signature, same names, same
  surrounding code — a `WRONG` that also lacks annotations, uses a global and swallows an error
  leaves the reader guessing which of the eight differences was the point, and they copy all eight.
- **A `CORRECT` obeys every other rule in these files** — `kw_only`, `@override`, `Final`, the `_`
  prefix, units in names, injected dependencies, one-line comments. Where a rule and an example
  disagree, the model has two instructions and picks one arbitrarily.
- **A `CORRECT` is real code**: it parses, it passes `mypy --strict`, and its library calls exist in
  the version the skill names. Run it before committing — `def f(...)` is a syntax error, and an
  API claim from memory is how a skill came to say `orjson` serialises `Decimal`.

**Both halves travel, which means neither names a project.** These files are read in every
repository, and a reader who has to know one codebase to understand an example learns nothing from
it — the local proper noun is noise to everyone else and rots the moment that code changes.
So: no domain entity from the project at hand, no vendor, service or model it happens to use, no
identifier copied out of it. Keep the **shape** of the incident and drop its names — "a native
library refuses to write its output file and reports only an exit code" carries the whole lesson,
where the library's name carried none of it. Domain vocabulary in examples stays deliberately
boring and universal: orders, users, notifications, repositories.

## What Holds These Rules Up

Three different things, and the difference matters most when a check passes:

- **The tools** decide syntax, imports, formatting, type errors and mechanical complexity. A green
  check means exactly that much and nothing else.
- **The type checker** decides what survives a rename, a narrowed union, a moved field. This is why
  `Any`, a stringly-typed dict and a silent `getattr` cost far more than the line they sit on.
- **Everything else rests on attention** — every rule here that no tool runs: the encapsulation
  test, the relocation test for names, one actor per module, the extraction tests, the layer
  intent. Nothing fails when they are skipped, and they are skipped first under pressure.

A rule in the third group that is broken in bulk is not a standard, it is a wish. Two honest
outcomes: write the check and move it into the first group, or delete it from this document. Run
that audit whenever violations turn up by the dozen — a rule nobody has followed for months was
never holding anything up.

## What Loads When

Two mechanisms, and which one a file lives in is the decision:

| | rule, `paths:` in front matter | rule, no front matter | skill |
|---|---|---|---|
| lives in | `~/.claude/rules/` | `~/.claude/rules/` | `~/.claude/skills/<name>/SKILL.md` |
| enters context | when a matching file is read | at launch, every session, every language | when its `description` matches the work, or by `/name` |
| always costs | nothing | its whole length | its `description`, ~40 tokens |

**A rule with no front matter is the expensive one, and it is the easy mistake.** Sixteen
reference files sat in `~/.claude/rules/` with no `paths:`, which is the documented instruction to
load every one of them into every session in every language — eighteen hundred lines, while the
pair that actually governs each edit waited on a glob. The prose in this section described the
opposite arrangement for months and nothing contradicted it, because nothing checks a claim about
loading.

So: what applies to every edit carries `paths: "**/*.py"`, one topic per file — `core.md`,
`naming.md`, `functions.md`, `classes.md`, `modules.md`, `types.md`, `errors.md`, `comments.md` —
and all of them load together on the first read; `testing.md` carries its own test-file globs.
Splitting by topic changes the organisation, not the cost: the same text arrives at the same moment.
Everything reached by a task rather than by a file — every topic, every library — is a skill, and
the map at the top of `core.md` names them.

**The one file with no front matter is `new-files.md`, six lines, and the exception is
measured.** A path-scoped rule loads when a matching file is *read*; a task that writes `x.py`
into an empty directory reads nothing, and in measured runs every such task went without the rules —
the dataclass scenario passed three of three with a file to read first and none of three without.
The six lines cost every session in every language; they buy the rules for the one case the glob
cannot see.

**Tool configuration is not written down here at all.** Which linters a project runs, what it
selects, what it excludes and how its hooks are wired changes from repository to repository, and
the person who owns the repository owns those files. What belongs here is only what survives the
choice of tool: the discipline around suppressions and limits, and — where a rule in these files
can be handed to a checker instead of remembered — the name of the check that does it.

**Moving a rule up costs every edit; moving it down costs a lookup.** A rule earns a place in the
always-loaded set by being both **universal** — every Python file could break it — and
**behaviour-changing**: without it the obvious default is wrong. A rule that only some paths reach
(async, migrations, a CLI, a shipped example) is a skill, and the map gets a row saying when it
applies. A rule that restates what the model already does by default is deleted, not moved: it
costs attention on every edit and buys nothing.

**A skill loads only when the work names its topic, so universal practice stays in the always-loaded
rules with its examples.** Measured, not assumed: a variant that left one-line rules in `core.md`
and moved the examples for functions, classes, errors and comments into four skills lost to the
current layout 38 to 42 of 42 runs, and none of the four skills was opened once — the model looks up
`sqlalchemy`, retries or a subprocess when the task contains them, and never looks up "how to write
a function". The actor rule was the clearest case: with the example in `core.md` the model split pay
and hours into two modules three times out of three; with the example one skill away it never did.
What moves to a skill is what a concrete signal in the task points at — a library, `async def`, a
migration, an untrusted input.

**The always-loaded set has a budget, and it is a hard number** — counted without front matter,
which Claude Code strips before loading:

| file | ceiling |
|---|---|
| `naming.md` | 300 |
| any other always-loaded file | 120 |
| **everything loaded on every `.py`** | **800** |
| any one `SKILL.md` | 500 |

The pair was lowered from 600 + 350 once, with this arithmetic: Anthropic asks for under 200 lines
in an always-loaded instruction file because adherence falls as the file grows, and 950 lines were
about twelve thousand tokens on every Python edit. An audit then found the contract sections, the
resource lifecycle, dunders and the stdlib-shadowing rule reached only by some work — they became
skill content — and a dozen rules the model follows without being told, which were deleted. What
remained was 800 lines; the ceiling is set there so the next addition has to displace something.
`core.md` was then split by topic with its text unchanged; the files load together, so the split
changes where a rule lives, not what reaches the model.

The number is not sacred; the *fixedness* is. Without one, every addition looks free — each is a
paragraph, and the file went from 350 lines to three thousand one paragraph at a time. With one,
**an addition displaces something**: find the rule it makes redundant, the example that has stopped
earning its lines, or the section that belongs in a skill, and cut that first. If nothing can be
cut, the new rule was not worth the space, and it becomes a skill with a row in the map.

The 500-line ceiling on a `SKILL.md` is not this project's invention — it is what Anthropic's
authoring guidance asks for, and past it a skill splits into reference files linked from
`SKILL.md`, **one level deep and no further**: a file reached through another file gets read in
fragments, `head -100` at a time, and the rule at line 200 silently does not arrive. A reference
file past a hundred lines opens with its own table of contents for the same reason.

Raising the ceiling is allowed exactly once per good argument, written down here with the
arithmetic — never because the file happens to have grown past it. A ceiling adjusted to fit the
current size is not a ceiling.

**Prefer the positive.** Steering by prohibition backfires — naming the thing to avoid makes it
more available, not less. Where a positive statement exists, lead with it and let the `# WRONG`
example carry the negative. Keep a bare `NEVER` for the rules where the wrong answer is genuinely
tempting and the right one is not obvious from the positive alone.

**Emphasis is rationed, and the reason does the work.** Current models follow instructions closely,
and capitals make them over-apply a rule to cases it was never meant for; a file where every second
line says `MUST` has no emphasis left for the one rule that keeps being skipped. State the rule
plainly with its reason — the model generalises from the reason — and bold the rule's name, not
its modality.

## One Rule, One Home

**A rule is written in exactly one file, and every other file points to it.** Three copies of the
retry policy drift into three policies; two files that disagree about where a test fake lives get
one of them followed at random. When a library skill needs a principle from a topic skill, it names
the skill — "see `python-boundaries`" — and adds only the library's mechanics.

**A carve-out lives beside its prohibition, even across files.** "Retry only in the adapter" in one
skill and "a deadlock retries the whole unit of work" in another are two contradictory rules until
each file states the exception in the same place as the rule.

## A Skill's Description Is Its Trigger

The `description` is all the model sees of a skill until it decides to load it, among a few dozen
others. It is written in the third person, says **what** the skill covers and then **when** to use
it, and puts the words a user or a file would actually contain first — library names, `async def`,
"slow", "migration" — because the listing is truncated from the end. A skill that never loads
teaches nothing; two skills whose descriptions both match the same work load the same text twice.

## Evaluation Before and After

A rule is a hypothesis that the model behaves differently with it than without it. Test it the way
it will be used: a realistic task that never mentions the rule, run in a fresh session without the
rule and then with it, a few times each, and the produced code read against the rule. Run it
without the rule first, to see that the default actually fails. A rule whose task passes without
it restates what the model already does, and is deleted. Seed the task with a file to read —
path-scoped rules arrive on a read — and keep the prompt free of requests that outrank the rule:
"make sure it is well documented" overrides any rule about comments, by design.
